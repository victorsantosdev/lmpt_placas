%Programa para a determina��o dos componentes do compensador de um conversor
%FORWARD; topologia de dois p�los

%Dados iniciais
VSAIDA=12;
VS=4;
Vpkmax=232.457936162;
POUT=120;
fs=40e03;
Ns=11;
Np=82;
RSE=0.13/3;
C=3000e-06;
L=500e-06;

%C�lculo de fz
fz=1/(2*pi*RSE*C);

%C�lculo de fo
fo=1/(2*pi*sqrt(L*C));

fmin=1;
fmax=10e03;

%C�lculo de G(s)

fmin=1;		%frequencia minima para os calculos
n=4;		%numero de decadas (+1) desejadas para os calculos
passos=100;	%n�mero de pontos calculados numa d�cada
i=1;		%variavel auxiliar


for d=0:n			%decada de calculo
	finf=fmin*10^d;		%frequ�ncia inferior da decada
	incremento=finf/passos;	%passo de calculo na decada
	fsup=10*finf-incremento;%frequ�ncia superior da d�cada
	
	for f=finf:incremento:fsup
			G(i)=(Vpkmax/VS)*(Ns/Np)*((1+((j*f)/fz))/(1+((j*f)/fo)^2));
			freq(i)=f;	%vetor de frequ�ncias
			i=i+1;
	endfor
endfor

for i=1:length(G)
	ganho(i)=20*log10(abs(G(i)));
endfor

clear G					%descarta o vetor G

semilogx(freq,ganho);
pause();				%espera pressionamento de tecla para continuar
for i=1:length(freq)
	if freq(i)==(fs/4)
		ganhofcruz=ganho(i);	%obt�m o ganho na frequ�ncia de cruzamento
	endif
endfor

A2=10^(-ganhofcruz/20);
A1=10^((-ganhofcruz-20*log10(fz/fo))/20);
