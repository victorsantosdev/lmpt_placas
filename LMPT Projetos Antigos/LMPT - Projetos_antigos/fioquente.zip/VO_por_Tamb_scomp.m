clc;
clear;
dados

TAMBi=0;
TAMBf=50;   
passoTAMB=(TAMBf-TAMBi)/500;
fim=(TAMBf-TAMBi)/passoTAMB;
alfaST=1*10^-12;
RST=RSTO*(1+alfaST*25);
RSTO=RST;
  
for contador1=0:fim
   TEMPERATURA(contador1+1)=TAMBi+contador1*passoTAMB;
   TAMB=TEMPERATURA(contador1+1);
   resis_sensor_scomp
   RSV(contador1+1)=SOL_RSV(1);
   TSV=(RSV(contador1+1)-RSVO)/(alfaSV*RSVO);
   VO(contador1+1)=((R2+RSV(contador1+1))/sqrt(RSV(contador1+1)))*sqrt(h*ASUP*(TSV-TAMB));
end

plot(TEMPERATURA,VO);
xlabel('Temperatura (graus Celsius)');
ylabel('Vo (V)');
title('Tens�o de sa�da X Temperatura do ar');
