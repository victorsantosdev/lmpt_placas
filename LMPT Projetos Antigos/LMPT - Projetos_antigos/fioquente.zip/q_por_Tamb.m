clc;
clear;
dados

TAMBi=0;
TAMBf=50;   
passoTAMB=(TAMBf-TAMBi)/500;
fim=(TAMBf-TAMBi)/passoTAMB;
      
for contador=0:fim
   TEMPERATURA(contador+1)=TAMBi+contador*passoTAMB;
   TAMB=TEMPERATURA(contador+1);
   resis_sensor
   RSV(contador+1)=SOL_RSV(1);
   q(contador+1)=(h*ASUP*(((RSV(contador+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
end

% Verifica se � necess�rio mudar a escala

multiplicador=0;

for contador=1:fim+1
   if q(contador)<0.05
      multiplicador=1;
   end
end

if multiplicador==1
   for contador=1:fim+1
      q(contador)=q(contador)*1000;
   end
end

plot(TEMPERATURA,q);
xlabel('Temperatura (graus Celsius)');
title('Pot�ncia dissipada X Temperatura do ar');

if multiplicador==1
   ylabel('q (mW)');
else
   ylabel('q (W)');
end
