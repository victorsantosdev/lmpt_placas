clc;
clear;
dados
vTAMB(1)=0;
vTAMB(2)=5;
vTAMB(3)=10;
vTAMB(4)=15;
vTAMB(5)=20;
vTAMB(6)=25;
vTAMB(7)=30;
vTAMB(8)=35;
vTAMB(9)=40;
vTAMB(10)=45;
vTAMB(11)=50;
vTAMB(12)=55;
vTAMB(13)=60;

for contador2=1:length(vTAMB)
   TAMB=vTAMB(contador2);
   VELi=0;
   VELf=10;   
   passoVEL=(VELf-VELi)/500;
   fim=(VELf-VELi)/passoVEL;
   
   for contador1=0:fim
      vVEL(contador1+1)=VELi+contador1*passoVEL;
      u=vVEL(contador1+1);
      resis_sensor
      RSV(contador1+1)=SOL_RSV(1);
      VO(contador1+1)=((R2+RSV(contador1+1))/sqrt(RSV(contador1+1)))*sqrt(h*ASUP*(((RSV(contador1+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end
   
   line(vVEL,VO);
   
      if contador2==1
      TEXTO_TAMB=num2str(TAMB);
      text(vVEL(contador1),VO(contador1),TEXTO_TAMB);
   elseif contador2==length(vTAMB)
      TEXTO_TAMB=num2str(TAMB);
      text(vVEL(contador1),VO(contador1),TEXTO_TAMB);
   end

end

   xlabel('Velocidade (m/s)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Velocidade do ar');
