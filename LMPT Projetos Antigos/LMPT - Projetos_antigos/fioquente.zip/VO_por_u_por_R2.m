clc;
clear;
dados
tolR2=0.05;
R2min=R2*(1-tolR2);
R2max=R2*(1+tolR2);
simulacoes_com_R2=5;
passoR2=(R2max-R2min)/simulacoes_com_R2;
VELi=0;
VELf=10;   
passoVEL=(VELf-VELi)/500;
fim=(VELf-VELi)/passoVEL;


for contador2=0:simulacoes_com_R2
   
   R2=((R2max-R2min)/simulacoes_com_R2)*contador2+R2min;
   
   for contador1=0:fim
      vVEL(contador1+1)=VELi+contador1*passoVEL;
      u=vVEL(contador1+1);
      resis_sensor
      RSV(contador1+1)=SOL_RSV(1);
      VO(contador1+1)=((R2+RSV(contador1+1))/sqrt(RSV(contador1+1)))*sqrt(h*ASUP*(((RSV(contador1+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end
   
   line(vVEL,VO);
   
   if contador2==0
      TEXTO_R2=num2str(R2);
      text(vVEL(contador1),VO(contador1),TEXTO_R2);
   elseif contador2==simulacoes_com_R2
      TEXTO_R2=num2str(R2);
      text(vVEL(contador1),VO(contador1),TEXTO_R2);
   end
      
end

   xlabel('Velocidade (m/s)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Velocidade do ar');
