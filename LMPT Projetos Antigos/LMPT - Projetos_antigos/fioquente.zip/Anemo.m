clear;

%Sele��o do tipo de simula��o

seleciona=0;	%Inicializa a vari�vel de sele��o

if seleciona~=1 | seleciona~=2 | seleciona~=3 | seleciona~=4
   clc;
   fprintf('Simulador para anem�metros a fio-quente\n\n\n\n\n');
   fprintf('Selecione o gr�fico desejado:\n\n');
   fprintf('1 - Tens�o de sa�da x temperatura ambiente\n');
   fprintf('2 - Tens�o de sa�da x velocidade do ar\n');
   fprintf('3 - Tens�o de sa�da x tens�o de off-set do amplificador\n');
   fprintf('4 - Tens�o de sa�da x ganho DC do amplificador\n\n\n');
   seleciona=input(':');
end

if seleciona==1
   clc
   fprintf('Ganho do amplificador (V/V)\n');
   AO=input(':');
   fprintf('\nTens�o de off-set do amplificador (V)\n');
   VOS=input(':');
   fprintf('\nDi�metro do fio (m)\n');
   d=input(':');
   fprintf('\nComprimento do fio (m)\n');
   L=input(':');
   fprintf('\nResistividade do fio a zero graus Celsius (Ohm*m)\n');
   roSVO=input(':');
   fprintf('\nCoeficiente de varia��o da resistividade do fio com a temperatura (Ohm*m/C)\n');
   alfaSV=input(':');
   fprintf('\nResist�ncia do sensor de temperatura a zero graus Celsius (Ohm)\n');
   RSTO=input(':');
   fprintf('\nCoeficiente de varia��o da resist�ncia do sensor de temperatura (Ohm*m/C)\n');
   alfaST=input(':');
   fprintf('\nR1 (em Ohm)\n');
   R1=input(':');
   fprintf('\nR2 (em Ohm)\n');
   R2=input(':');
   fprintf('\nVelocidade do ar (m/s)\n');
   u=input(':');
   fprintf('\nTemperatura inicial do ar (graus Celsius)\n');
   TAMBi=input(':');
   fprintf('\nTemperatura final do ar (graus Celsius)\n');
   TAMBf=input(':');
   
   passoTAMB=(TAMBf-TAMBi)/500;
   fim=(TAMBf-TAMBi)/passoTAMB;
   
   for contador=0:fim
      TEMPERATURA(contador+1)=TAMBi+contador*passoTAMB;
      TAMB=TEMPERATURA(contador+1);
      resis_sensor
      RSV(contador+1)=SOL_RSV(1);
      VO(contador+1)=((R2+RSV(contador+1))/sqrt(RSV(contador+1)))*sqrt(h*ASUP*(((RSV(contador+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end
   
   plot(TEMPERATURA,VO);
   xlabel('Temperatura (graus Celsius)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Temperatura do ar');

   
elseif seleciona==2
   clc
   fprintf('Ganho do amplificador (V/V)\n');
   AO=input(':');
   fprintf('\nTens�o de off-set do amplificador (V)\n');
   VOS=input(':');
   fprintf('\nDi�metro do fio (m)\n');
   d=input(':');
   fprintf('\nComprimento do fio (m)\n');
   L=input(':');
   fprintf('\nResistividade do fio a zero graus Celsius (Ohm*m)\n');
   roSVO=input(':');
   fprintf('\nCoeficiente de varia��o da resistividade do fio com a temperatura (Ohm*m/C)\n');
   alfaSV=input(':');
   fprintf('\nResist�ncia do sensor de temperatura a zero graus Celsius (Ohm)\n');
   RSTO=input(':');
   fprintf('\nCoeficiente de varia��o da resist�ncia do sensor de temperatura (Ohm*m/C)\n');
   alfaST=input(':');
   fprintf('\nR1 (em Ohm)\n');
   R1=input(':');
   fprintf('\nR2 (em Ohm)\n');
   R2=input(':');
   fprintf('\nTemperatura do ar (graus Celsius)\n');
   TAMB=input(':');
   fprintf('\nVelocidade inicial do ar (m/s)\n');
   VELi=input(':');
   fprintf('\nVelocidade final do ar (m/s)\n');
   VELf=input(':');
   
   passoVEL=(VELf-VELi)/500;
   fim=(VELf-VELi)/passoVEL;
   
   for contador=0:fim
      VEL(contador+1)=VELi+contador*passoVEL;
      u=VEL(contador+1);
      resis_sensor
      RSV(contador+1)=SOL_RSV(1);
      VO(contador+1)=((R2+RSV(contador+1))/sqrt(RSV(contador+1)))*sqrt(h*ASUP*(((RSV(contador+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end   
   
   plot(VEL,VO)
   xlabel('Velocidade (m/s)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Velocidade do ar');
   
elseif seleciona==3
   clc
   fprintf('Ganho do amplificador (V/V)\n');
   AO=input(':');
   fprintf('\nDi�metro do fio (m)\n');
   d=input(':');
   fprintf('\nComprimento do fio (m)\n');
   L=input(':');
   fprintf('\nResistividade do fio a zero graus Celsius (Ohm*m)\n');
   roSVO=input(':');
   fprintf('\nCoeficiente de varia��o da resistividade do fio com a temperatura (Ohm*m/C)\n');
   alfaSV=input(':');
   fprintf('\nResist�ncia do sensor de temperatura a zero graus Celsius (Ohm)\n');
   RSTO=input(':');
   fprintf('\nCoeficiente de varia��o da resist�ncia do sensor de temperatura (Ohm*m/C)\n');
   alfaST=input(':');
   fprintf('\nR1 (em Ohm)\n');
   R1=input(':');
   fprintf('\nR2 (em Ohm)\n');
   R2=input(':');
   fprintf('\nVelocidade do ar (m/s)\n');
   u=input(':');
   fprintf('\nTemperatura do ar (graus Celsius)\n');
   TAMB=input(':');
   fprintf('\nTens�o de off-set inicial (V)\n');
   VOSi=input(':');
   fprintf('\nTens�o de off-set final (V)\n');
   VOSf=input(':');
   
   passoVOS=(VOSf-VOSi)/500;
   fim=(VOSf-VOSi)/passoVOS;
   
   for contador=0:fim
      vVOS(contador+1)=VOSi+contador*passoVOS;
      VOS=vVOS(contador+1);
      resis_sensor
      RSV=SOL_RSV(1);
      VO(contador+1)=((R2+RSV)/sqrt(RSV))*sqrt(h*ASUP*(((RSV-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end   
   
   plot(vVOS,VO)
   xlabel('Vos (V)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Tens�o de off-set');

   
elseif seleciona==4
   clc
   fprintf('\nDi�metro do fio (m)\n');
   d=input(':');
   fprintf('\nComprimento do fio (m)\n');
   L=input(':');
   fprintf('\nResistividade do fio a zero graus Celsius (Ohm*m)\n');
   roSVO=input(':');
   fprintf('\nCoeficiente de varia��o da resistividade do fio com a temperatura (Ohm*m/C)\n');
   alfaSV=input(':');
   fprintf('\nResist�ncia do sensor de temperatura a zero graus Celsius (Ohm)\n');
   RSTO=input(':');
   fprintf('\nCoeficiente de varia��o da resist�ncia do sensor de temperatura (Ohm*m/C)\n');
   alfaST=input(':');
   fprintf('\nR1 (em Ohm)\n');
   R1=input(':');
   fprintf('\nR2 (em Ohm)\n');
   R2=input(':');
   fprintf('\nVelocidade do ar (m/s)\n');
   u=input(':');
   fprintf('\nTemperatura do ar (graus Celsius)\n');
   TAMB=input(':');
   fprintf('\nTens�o de off-set do amplificador (V)\n');
   VOS=input(':');
   fprintf('\nGanho inicial do amplificador (V/V)\n');
   AOi=input(':');
   fprintf('\nGanho final do amplificador (V/V)\n');
   AOf=input(':');

   
   passoAO=(AOf-AOi)/500;
   fim=(AOf-AOi)/passoAO;
   
   for contador=0:fim
      vAO(contador+1)=AOi+contador*passoAO;
      AO=vAO(contador+1);
      resis_sensor
      RSV=SOL_RSV(1);
      VO(contador+1)=((R2+RSV)/sqrt(RSV))*sqrt(h*ASUP*(((RSV-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end   
   
   plot(vAO,VO)
   xlabel('AO (V/V)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Ganho DC do amplificador');

end
