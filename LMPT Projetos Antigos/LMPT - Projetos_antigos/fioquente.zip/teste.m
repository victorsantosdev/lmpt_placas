
solve('RSVo*exp(-a*(x-TSVo))*I^2=h*A*(x-Tamb)')

solve('exp(a*x)*(x-Tamb)=(RSVo*I^2*exp(TSVo))/(h*A)')