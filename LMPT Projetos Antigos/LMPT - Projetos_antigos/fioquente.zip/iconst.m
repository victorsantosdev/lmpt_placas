clear;
clc;

r=1.5*10^-3;
l=0.5*10^-3;
A=2*pi*r*(r+l);

h=50;

Tamb=30;

TSVo=25;
RSVo=3600;
a=0.05;

I=20*10^-3;

Tamb=0:0.1:40;

for contador=1:length(Tamb)
   TSV(contador)=(lambertw(a*RSVo*I^2/h/A*exp(-a*Tamb(contador)+a*TSVo))+a*Tamb(contador))/a;
   RSV(contador)=RSVo*exp(-a*(TSV(contador)-TSVo));
   Vo(contador)=RSV(contador)*I;
end


% Aproxima��es lineares

TSV_ap(1)=TSV(1);
TSV_ap(2)=TSV(length(TSV));

RSV_ap(1)=RSV(1);
RSV_ap(2)=RSV(length(TSV));

Vo_ap(1)=Vo(1);
Vo_ap(2)=Vo(length(TSV));

Tamb_ap(1)=Tamb(1);
Tamb_ap(2)=Tamb(length(Tamb));

% Plota resultados

figure(1);
plot(Tamb,TSV);
hold on;
plot(Tamb_ap,TSV_ap);
hold off;
xlabel('Tamb');
ylabel('TSV');

figure(2);
plot(Tamb,RSV);
hold on;
plot(Tamb_ap,RSV_ap);   
hold off;
xlabel('Tamb');
ylabel('RSV (Ohms)');

figure(3);
plot(Tamb,Vo);
hold on;
plot(Tamb_ap,Vo_ap);
hold off;
xlabel('Tamb');
ylabel('Vo (V)');

%TSV=25:0.01:100;
%for contador=1:length(TSV)
%   q1(contador)=RSVo*exp(-a*(TSV(contador)-TSVo))*I^2;
%end
%plot (TSV,q1);

%for contador=1:length(TSV)
%   q2(contador)=h*A*(TSV(contador)-Tamb);
%end

%hold on;
%plot (TSV,q2);
%hold off;
