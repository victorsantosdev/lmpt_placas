%C�lculo da resist�ncia do sensor de velocidade (resultado em SOL_RSV(1))

ASUP=pi*d*L;
RSVO=(4*roSVO*L)/(pi*d^2);
h=(910*10^-6)*(d^-1)+0.41*(d^-0.48)*u^0.52;
AUX1=(R1*(AO+1)+RST)^2;
AUX2=alfaSV*RSVO;
AUX3=(alfaSV*RSVO*(RSTO-RST)-alfaST*RSTO*RSVO)/(alfaSV*alfaST*RSVO*RSTO);
AUX4=2*R2*(AO*(AO*R1*RST+(RST^2)-(R1^2))-(R1+RST)^2);
AUX5=(R2^2)*(RST*(AO-1)-R1)^2;
AUX6=((AO*VOS*(R1+RST))^2)/(h*ASUP);
A=AUX1/AUX2;
B=AUX1*AUX3-AUX4/AUX2;
C=(AUX5/AUX2)-AUX4*AUX3-AUX6;
D=AUX5*AUX3;
a=[A B C D];
SOL_RSV=roots(a);

%Coloca as ra�zes em ordem crescente

for n=1:2,
   for m=n+1:3
      if SOL_RSV(n)>SOL_RSV(m)
         TEMP=SOL_RSV(n);
         SOL_RSV(n)=SOL_RSV(m);
         SOL_RSV(m)=TEMP;
      end
   end
end

%Verifica qual raiz deve ser utilizada


RSV_IDEAL=(R2*RST)/R1;
VO_IDEAL=((R2+RSV_IDEAL)/sqrt(RSV_IDEAL))*sqrt(h*ASUP*(((RSV_IDEAL-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));

solucoes_validas=0;

for m=1:3
   solucao_valida(m)=0;
   VO_SOL1(m)=((R2+SOL_RSV(m))/sqrt(SOL_RSV(m)))*sqrt(h*ASUP*(((SOL_RSV(m)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   VO_SOL2(m)=((R1+RST)*(R2+SOL_RSV(m))*AO*VOS)/((R2*RST-R1*SOL_RSV(m))*AO-(R1+RST)*(R2+SOL_RSV(m)));
   DIF1(m)=VO_IDEAL-VO_SOL1(m);
   DIF2(m)=VO_SOL1(m)-VO_SOL2(m);
   
   if VO_SOL1(m)>0
      if VO_SOL2(m)>0
         if abs(DIF2(m))<=1*10-6
            solucoes_validas=solucoes_validas+1;
         end
      end
   end
   
end

ABS_DIF=abs(DIF1);

if solucoes_validas>2
   for k=1:solucoes_validas-1
      for m=k+1:solucoes_validas
         if ABS_DIF(m)<ABS_DIF(k)
            TEMP=SOL_RSV(k);
            SOL_RSV(k)=SOL_RSV(m);
            SOL_RSV(m)=TEMP;
         end
      end
   end
elseif solucoes_validas==2
   if ABS_DIF(2)<ABS_DIF(1)
      TEMP=SOL_RSV(1);
      SOL_RSV(1)=SOL_RSV(2);
      SOL_RSV(2)=TEMP;
   end
end

clear AUX* A B C D a TEMP RSV_IDEAL VO_IDEAL VO__SOL* solucoes_validas ABS_DIF