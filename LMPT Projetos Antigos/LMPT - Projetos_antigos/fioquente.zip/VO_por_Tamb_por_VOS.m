clc;
clear;
dados
vVOS(1)=1*10^-6;
vVOS(2)=5*10^-6;
vVOS(3)=10*10^-6;
vVOS(4)=50*10^-6;
vVOS(5)=100*10^-6;
vVOS(6)=500*10^-6;
vVOS(7)=1*10^-3;
vVOS(8)=5*10^-3;
vVOS(9)=10*10^-3;

   TAMBi=0;
   TAMBf=50;   
   passoTAMB=(TAMBf-TAMBi)/500;
   fim=(TAMBf-TAMBi)/passoTAMB;

for contador2=1:length(vVOS)
   VOS=vVOS(contador2);
   
   for contador1=0:fim
      TEMPERATURA(contador1+1)=TAMBi+contador1*passoTAMB;
      TAMB=TEMPERATURA(contador1+1);
      resis_sensor
      RSV(contador1+1)=SOL_RSV(1);
      VO(contador1+1)=((R2+RSV(contador1+1))/sqrt(RSV(contador1+1)))*sqrt(h*ASUP*(((RSV(contador1+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end
   
   line(TEMPERATURA,VO);
   
   if contador2==1
      TEXTO_VOS=num2str(VOS);
      text(TEMPERATURA(contador1),VO(contador1),TEXTO_VOS);
   elseif contador2==length(vVOS)
      TEXTO_VOS=num2str(VOS);
      text(TEMPERATURA(contador1),VO(contador1),TEXTO_VOS);
   end
   
end

   xlabel('Temperatura (graus Celsius)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Temperatura do ar');
