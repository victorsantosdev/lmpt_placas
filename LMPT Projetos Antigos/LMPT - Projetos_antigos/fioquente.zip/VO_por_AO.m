clear;
clc;
dados

AOi=500;
AOf=200*10^3;

passoAO=(AOf-AOi)/500;
fim=(AOf-AOi)/passoAO;
   
for contador=0:fim
   vAO(contador+1)=AOi+contador*passoAO;
   AO=vAO(contador+1);
   resis_sensor
   RSV=SOL_RSV(1);
   VO(contador+1)=((R2+RSV)/sqrt(RSV))*sqrt(h*ASUP*(((RSV-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
end   

plot(vAO,VO)
xlabel('AO (V/V)');
ylabel('Vo (V)');
title('Tens�o de sa�da X Ganho DC do Amplificador');

