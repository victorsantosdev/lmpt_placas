clc;
clear;
dados
vAO(1)=500;
vAO(2)=1000;
vAO(3)=5*10^3;
vAO(4)=10*10^3;
vAO(5)=50*10^3;
vAO(6)=100*10^3;
vAO(7)=500*10^3;
vAO(8)=1*10^6;
vAO(9)=5*10^6;
vAO(10)=10*10^6;
vAO(11)=50*10^6;
vAO(12)=100*10^6;

for contador2=1:length(vAO)
   AO=vAO(contador2);
   TAMBi=0;
   TAMBf=50;   
   passoTAMB=(TAMBf-TAMBi)/500;
   fim=(TAMBf-TAMBi)/passoTAMB;
   
   for contador1=0:fim
      TEMPERATURA(contador1+1)=TAMBi+contador1*passoTAMB;
      TAMB=TEMPERATURA(contador1+1);
      resis_sensor
      RSV(contador1+1)=SOL_RSV(1);
      VO(contador1+1)=((R2+RSV(contador1+1))/sqrt(RSV(contador1+1)))*sqrt(h*ASUP*(((RSV(contador1+1)-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
   end
   
   line(TEMPERATURA,VO);
   
   if contador2==1
      TEXTO_AO=num2str(AO);
      text(TEMPERATURA(contador1),VO(contador1),TEXTO_AO);
   elseif contador2==length(vAO)
      TEXTO_AO=num2str(AO);
      text(TEMPERATURA(contador1),VO(contador1),TEXTO_AO);
   end
   
end

   xlabel('Temperatura (graus Celsius)');
   ylabel('Vo (V)');
   title('Tens�o de sa�da X Temperatura do ar');
