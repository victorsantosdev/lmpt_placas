clear;
clc;
dados

VOSi=1*10^-6;
VOSf=10*10^-3;

passoVOS=(VOSf-VOSi)/500;
fim=(VOSf-VOSi)/passoVOS;
   
for contador=0:fim
   vVOS(contador+1)=VOSi+contador*passoVOS;
   VOS=vVOS(contador+1);
   resis_sensor
   RSV=SOL_RSV(1);
   VO(contador+1)=((R2+RSV)/sqrt(RSV))*sqrt(h*ASUP*(((RSV-RSVO)/(alfaSV*RSVO))-((RST-RSTO)/(alfaST*RSTO))));
end   

vVOS=1000*vVOS;
plot(vVOS,VO)
xlabel('Vos (mV)');
ylabel('Vo (V)');
title('Tens�o de sa�da X Tens�o de off-set');

