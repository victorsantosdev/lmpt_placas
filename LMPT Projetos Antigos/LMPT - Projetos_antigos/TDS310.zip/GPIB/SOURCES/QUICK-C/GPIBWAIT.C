#include "decl.h"
#include <string.h>
int gpibWrite( int dev, char *cmd);          /* gpib write function with wait */
int gpibRead( int dev, char *resp, int cnt );/* gpib read function with wait */

/*******************************************************************
 *  gpibWait - wait for a gpib command to finish by doing a query
 *  and reading its results; wait only as long as the delay value
 *******************************************************************/
int gpibWaitCom(int dev, int delay)
{
	char rd[6];

	gpibWrite(dev,"*OPC?");

	if(ibsta >= 0)
		gpibRead(dev,rd, strlen(rd));

	return(ibsta);
}


