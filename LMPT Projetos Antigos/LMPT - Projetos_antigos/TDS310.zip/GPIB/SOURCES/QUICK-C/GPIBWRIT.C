#include "decl.h"
#include <string.h>
/*********************************************************************
 *  gpibWrite - send the contents of the string to the device and wait
 *  for the write to finish.
 *********************************************************************/
int gpibWrite( int dev, char *cmd)
{
	int cmd_len;

	cmd_len = strlen(cmd);

	/*
	 * set the timeout for 10 seconds, send the command
	 * wait for the scope to finish processing the command.
	 */
	ibtmo(dev,13);
	ibwrt (dev,cmd,cmd_len);

	/*
	 * If ibwrt was successful, wait for scope completion.
	 */
	if(ibsta >=0)
		ibwait(dev,STOPend);

	return(ibsta);
 }

