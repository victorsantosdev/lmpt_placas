/*
 *  meas.c - program to measure a parameter of an oscilloscope waveform
 *
 *  NOTE:  Assign a unique identifier to the device. This identifier is defined
 *         in your GPIB.COM file using the program IBCONF.EXE. This example
 *         program assumes that the device is DEV1.
 *  Version: 1.0
 */

#include "decl.h"
#include <stdio.h>
#include <conio.h>
#include <process.h>
#include <stdlib.h>
#include <memory.h>

void main(void);                             /* main line function prototype */
int gpibWrite( int dev, char *cmd);          /* gpib write function with wait */
int gpibRead( int dev, char *resp, int cnt );/* gpib read function with wait */
int gpibWaitCom(int dev, int delay);         /* gpib delay function */
void gpiberr(char *msg);                     /* gpib error display function */

void main()
{
	int scope;              /* handle for scope address in device DEV1 */
	int brd;                /* handle for gpib board: GPIB0 */
	char measval[15];       /* scope volts per division setting */

	/*
	 * Initialize the memory locations used by the string variable
	 * to ensure that the variable is null terminated after a gpib read.
	 */
	memset(measval,0,15);

	/*
	 * Assign unique identifier to the device DEV1, store it in
	 * the variable "scope", and check for errors. If DEV1 is not
         * defined, ibfind returns -1.
	 */
	if( ((scope = ibfind("DEV1")) < 0) ||
	    ((brd = ibfind("GPIB0")) < 0))
	{
		gpiberr("ibfind Error: Unable to find device/board!");
		exit(0);
	}

	/*
	 *  Clear the device and check for errors
	 */
	if((ibclr(scope) < 0) ||
	   (ibsre(brd,0) < 0))
	{
		gpiberr("ibclr/ibsre Error: Unable to clear device/board!");
		exit(0);
	}

/*
 *  Clear any existing menus, run the factory initialization, then lock out
 *  the front panel so there are no changes made to settings
 */
	if((gpibWrite(scope,"CLEARMENU") < 0) ||
	   (gpibWrite(scope,"FACTORY") < 0) ||
	   (gpibWrite(scope,"LOCK ALL") < 0) )
    {
	gpiberr("ibwrt Error:Unable to initialize gpib device!");
	exit(0);
    }

/*
 *  Print a message on the screen instructing the user to connect Channel 1
 *  to the test signal.
 */
	printf("\n\n\t     TDS 300 Series MEAS Program - Version 1.0\n\n\n");
	printf("\t***  Connect your test signal to Channel 1  ***\n\n");
	printf("\t     For example, you might connect the PROBE COMP signal\n");
	printf("\t     to the Channel 1 input connector using a 10X probe.\n");
	printf("\t     \n\n");
	printf("\t***  Press any key when done \n");
	getch();

/*
 *  Wait for the scope to finish the factory command.
 */
	if (gpibWaitCom(scope,12) < 0 )
	{
		gpiberr("gpibWaitCom Error:  Device timed out!");
		exit(0);
	}
/*
 *  Turn off the header from query responses.
 */
	if(gpibWrite(scope,"HEADER OFF") < 0)
	{
		gpiberr("gpibWrite Error: Unable to write to Device!");
		exit(0);
	}

/*
 *  Set up the measurement source to be channel 1; the type to amplitude, and
 *  wait for the scope to display the waveform and the measurement.
 */
	if((gpibWrite(scope,":MEASUREMENT:MEAS1:SOURCE1 CH1;TYPE AMPLITUDE;STATE 1") < 0) ||
	   (gpibWaitCom(scope,12) < 0))
	{
		gpiberr("gpibWrite Error: Unable to setup signal!");
		exit(0);
	}
/*
 *  Print the display message for the user.
 */
	printf("\n\n\t     The CH1 waveform and its AMPLITUDE\n");
	printf("\t     are displayed on the oscilloscope screen\n\n");

/*
 *  Unlock the front panel so the user can update the front panel.
 */
	if(gpibWrite(scope,"UNLOCK ALL") < 0)
	{
		gpiberr("gpibWrite Error: Unable to Unlock Front Panel!");
		exit(0);
	}
}
