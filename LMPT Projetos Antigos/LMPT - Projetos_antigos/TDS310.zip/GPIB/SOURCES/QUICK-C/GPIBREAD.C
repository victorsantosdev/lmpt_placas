#include "decl.h"
/*******************************************************************
 *  gpibRead - read into the string from the device and wait for the
 *  read to finish.
 *******************************************************************/

 int gpibRead( int dev, char *resp, int cnt )
 {
	/*
	 * set the timeout for 10 seconds, send the command, and
	 * wait for the scope to finish processing the command.
	 */
	ibtmo(dev,13);
	ibrd(dev,resp,cnt);
	/*
	 * If ibrd was successful, wait for scope completion.
	 */
	if(ibsta >=0)
		ibwait(dev,STOPend);

	return(ibsta);
 }
