/*
 * tl.c - program to send commands and queries to the oscilloscope and to
 * display status and query results
 *
 * Version 1.0.
 */

#include "decl.h"
#include <stdio.h>
#include <string.h>
#include <conio.h>
#include <process.h>
#include <stdlib.h>
#include <memory.h>

/*
 *  NOTE:  Assign a unique identifier to device in your GPIB.COM file
 *         using the program IBCONF.EXE.  This program assumes that device
 *         to be DEV1.
 */

void main(void);    /* main line function prototype */
int gpibWrite( int dev, char *cmd); /* gpib write function w/wait */
int gpibRead( int dev, char *resp, int cnt );/* gpib read function w/wait */
int gpibWaitCom(int dev, int delay);         /* gpib delay function */
void gpiberr(char *msg);                     /* gpib error display function */
int doQuery(int scope);                      /* get response from scope */
int doCmd( int scope, char *cmd );           /* send command to scope */

void main()
{
	int scope;              /* handle for scope address in device DEV1 */
	int brd;                /* handle for gpib board: GPIB0 */
	char cmd[80];           /* user entered command */

	printf("\n\nTDS 300 Series TL (Talker-Listener) Program - Version 1.0\n\n\n");
	/*
	 * Assign unique identifier to the device DEV1 and store in
	 * variable scope.  Check for error.  ibfind returns -1 if
	 * DEV1 not defined.
	 */
	if( ((scope = ibfind("DEV1")) < 0) ||
	    ((brd = ibfind("GPIB0")) < 0))
	{
		gpiberr("ibfind Error: Unable to find device/board!");
		exit(0);
	}

	/*
	 *  Clear the device and check for errors
	 */
	if((ibclr(scope) < 0) ||
	   (ibsre(brd,0) < 0))
	{
		gpiberr("ibclr/ibsre Error: Unable to clear device/board!");
		exit(0);
	}

	/*
	 * Set up Device Event Status Enable Register to enable status events
	 * Set up the Event Status Enable Register to enable status events
	 * Set up the Service Request Enable Register to enable status events
	 */
	if((gpibWrite(scope,"DESE 255") < 0) ||
	   (gpibWrite(scope,"*ESE 255") < 0) ||
	   (gpibWrite(scope,"*SRE 48") < 0))
	{
		gpiberr("GPIBWRITE Error: Unable to Initialize Device!");
		exit(0);
	}

	/*
	 * Print message instructing the user to enter a command or query
	 */
	while(1)
	{
		memset(cmd,0,80);       /* initialize command string */
		printf("Input command or query ('q' to exit) ");
		gets(cmd);

		/*
		 * if the command is a 'q' char then quit program
		 */
		if(strcmp(strupr(cmd),"Q")==0)
			exit(0);

		/*
		 * send the user specified command to the oscilloscope;
		 * if there was a gpib error then print the result and
		 * exit the program
		 */
		if(doCmd(scope, cmd) < 0)
		{
			gpiberr("Command Error:");
			exit(-1);
		}

		/*
		 * if the command string contains a question mark, '?',
		 * then read back any response from the scope;  if there
		 * was a gpib error then print the result and exit the program
		 */
		if(strstr(cmd,"?") != 0)
		{
			/*
			 * get the response back and print results
			 */
			if(doQuery(scope) < 0)
			{
				gpiberr("Query Error:");
				exit(-1);
			}
		}
	}
 }
 int doCmd( int scope, char *cmd )
 {
	int mask=0x4800;        /* 4800 hex means srq mask */
	char resp;              /* response byte */
	char allEvents[120];    /* event response string */

	/*
	 * get the string length and check for error
	 */
	if(gpibWrite(scope,cmd) < 0)
		return(-1);

	/*
	 * if no error occurred, print the number of bytes sent
	 */
	printf("\n\n<%d characters sent>\n",ibcnt);

	/*
	 *  Set a timeout value of 100 ms to allow the gpib parser time
	 *  to see if the command or query is legal
	 */
	ibtmo(scope,T100ms);

	/*
	 *  Wait for either the timeout to occur or for the scope to request
	 *  service, indicating there was a problem with the command or query
	 */
	ibwait(scope,mask);

	/*
	 *  Set the timeout value back to 10 seconds
	 */
	ibtmo(scope, T10ms);

	/*
	 *  Get the status bits of the scope
	 */
	ibrsp(scope,&resp);
	if(ibsta<0)
		return(-1);

	/*
	 *  Check whether the MSS and ESB bits are set in the Status Byte
	 *  Register, indicating a possible command problem
	 */
	if(resp == 0x60)
	{
		if((gpibWrite(scope,"*ESR?")<0) ||
		  (gpibRead(scope, &resp, 1) < 0))
			return(-1);
		if((resp & 0x20) == 0x20)
		{
			printf("\n\n  ###  Bad command or query ###\n");
		}
		else
		{
			if((resp&0x40) == 0x40)
			{
				printf("  ###  USER REQUEST asserted  ###\n");
			}
		}
		printf("     *ESR value is %c\n",resp);
		if((gpibWrite(scope,"ALLEV?") < 0) ||
		   (gpibRead(scope,allEvents,120) < 0))
		   return(-1);

		allEvents[ibcnt] = '\0';  /* force a null terminated string */
		printf("ALLEV response is %s\n",allEvents);
	}
	return(0);
}

int doQuery(int scope)
{
	long numChar=0;         /* total number of bytes transferred */
	char resp[320];         /* buffer containing bytes transferred */
	char spr;               /* serial poll request byte */

	printf("Query response is: ");
	do{
		/*
		 * get the response in increments of 320
		 */
		memset(resp,0,320);
		if(gpibRead(scope,resp,319) < 0)
			return(-1);

		/*
		 * print the query response
		 */
		resp[ibcnt]='\0';       /* force a null terminated string */
		numChar +=ibcnt;        /* increment the counter */
		printf("%s",resp);      /* print the response */
		ibrsp(scope,&spr);      /* poll the SBR for more data */
	} while((spr & 0x10) == 0x10);

	/*
	 *  Print the number of characters received; do not include the EOI
	 *  character which is received with every response, only the printable
	 *  characters
	 */
	printf("\n\n");
	printf("<%ld characters received>\n", numChar-1);

	return(0);
}
