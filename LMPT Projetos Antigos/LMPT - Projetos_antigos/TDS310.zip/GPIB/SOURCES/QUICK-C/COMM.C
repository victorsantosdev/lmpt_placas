/*
 *  comm.c - program to show communication between the controller and the
 *  oscilloscope
 *
 *  NOTE:  Assign a unique identifier to the device. This identifier is defined
 *         in your GPIB.COM file using the program IBCONF.EXE. This example
 *	   program assumes that the device is DEV1.
 *  Version 1.0.
 */
#include "decl.h"
#include <stdio.h>
#include <conio.h>
#include <process.h>
#include <stdlib.h>
#include <memory.h>

void main(void);                             /* main line function prototype */
int gpibWrite( int dev, char *cmd ); /* gpib write function with wait */
int gpibRead( int dev, char *resp, int cnt );/* gpib read function with wait */
int gpibWaitCom(int dev, int delay);         /* gpib delay function */
void gpiberr(char *msg);                     /* gpib error display function */

void main()
{
	int scope;      /* handle for scope address in device DEV1 */
	int brd;        /* handle for gpib board: GPIB0 */
	char volts[15]; /* scope volts per division setting */
	char sec[15];   /* scope seconds per division setting */

	/*
	 * Initialize the memory locations used by the two string variables
	 * to ensure that the variables are null terminated after a gpib read.
	 */
	memset(volts,0,15);
	memset(sec,0,15);

	/*
	 * Assign unique identifier to the device DEV1, store it in
	 * the variable "scope", and check for errors. If DEV1 is not
         * defined, ibfind returns -1.
	 */
	if( ((scope = ibfind("DEV1")) < 0) ||
	    ((brd = ibfind("GPIB0")) < 0))
	{
		gpiberr("ibfind Error: Unable to find device/board!");
		exit(0);
	}

	/*
	 *  Clear the device and check for errors.
	 */
	if((ibclr(scope) < 0) ||
	   (ibsre(brd,0) < 0))
	{
		gpiberr("ibclr/ibsre Error: Unable to clear device/board!");
		exit(0);
	}

/*
 *  Clear any existing menus, run the factory initialization, then lock out
 *  the front panel so there are no changes made to settings.
 */
	if((gpibWrite(scope,"CLEARMENU") < 0) ||
	   (gpibWrite(scope,"FACTORY") < 0) ||
	   (gpibWrite(scope,"LOCK ALL") < 0) )
    {
	gpiberr("ibwrt Error:Unable to initialize gpib device!");
	exit(0);
    }

/*
 *  Print a message on the screen instructing the user to connect Channel 1
 *  to the test signal.
 */
	printf("\n\n\t     TDS 300 Series COMM Program - Version 1.0\n\n\n");
	printf("\t***  Connect your test signal to Channel 1  ***\n\n");
	printf("\t     For example, you might connect the PROBE COMP signal\n");
	printf("\t     to the Channel 1 input connector using a 10X probe.\n");
	printf("\t     \n\n");
	printf("\t***  Press any key when done \n");
	getch();

/*
 *  Wait for the scope to finish the factory command.
 */
	if (gpibWaitCom(scope,12) < 0 )
	{
		gpiberr("gpibWaitCom Error:  Device timed out!");
		exit(0);
	}
/*
 *  Turn off the header from query responses.
 */
	if(gpibWrite(scope,"HEADER OFF") < 0)
	{
		gpiberr("gpibWrite Error: Unable to write to Device!");
		exit(0);
	}
/*
 *  Send the autoset command to display the calibrator signal.
 */
	if(gpibWrite(scope,"AUTOSET EXECUTE") < 0)
	{
		gpiberr("gpibWrite Error: Unable to AUTOSET device!");
		exit(0);
	}
	printf("\n\n\t     An autoset of the Channel 1 waveform ");
	printf("is now being performed\n");
/*
 *  Query the oscilloscope for its selected VOLTS/DIV setting and TIME/DIV
 *  setting.
 */
	if((gpibWrite(scope,"CH1:SCALE?") < 0) ||
	   (gpibRead(scope, volts, 14) < 0) ||
	   (gpibWrite(scope,"HORIZONTAL:MAIN:SCALE?") < 0) ||
	   (gpibRead(scope, sec, 14) < 0))
	{
		gpiberr("gpib-Read/Write Error: Unable to set\nVolts/DIV or Sec/DIV!");
		exit(0);
	}

/*
 *  Print the query responses for the user.
 */
	printf("\n\n\t     The VOLTS/DIV setting is %s",volts);
	printf("\n\t     The SEC/DIV setting is %s\n\n",sec);

/*
 *  Unlock the front panel so the user can update the front panel.
 */
	if(gpibWrite(scope,"UNLOCK ALL") < 0)
	{
		gpiberr("gpibWrite Error: Unable to Unlock Front Panel!");
		exit(0);
	}
}
