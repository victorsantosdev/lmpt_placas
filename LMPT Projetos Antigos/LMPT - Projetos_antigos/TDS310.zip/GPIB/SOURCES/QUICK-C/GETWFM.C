/*
 *      getwfm.c - a  simple waveform to ASCII file format converter that
 *	produces ASCII output in generic format suitable for importing to
 *	Lotus 123.
 *
 *      Version 1.0.
 *
 *  NOTE:  Assign unique identifiers to the device and to the board. The
 *         identifiers are defined in your GPIB.COM file using the program
 *	   IBCONFIG.EXE. This example program assumes that the device is DEV1
 *         and the board is GPIB0.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <time.h>
#include <graph.h>

#include "decl.h"

void main( void );	      /* main line function prototype */
int gpibWrite( int scope, char *cmd);
int gpibRead( int scope, char *cmd, int cnt);
int gpibWaitCom( int scope, int delay );
void gpiberr(char *msg);                      /* gpib error function   */

void main(){
	int scope;              /* address of scope */
	int brd;                /* handle for gpib board: GPIB0 */
	int rslt;               /* error return variable */
	char wfm[1040];         /* array for raw scope input */
	FILE *outfile;          /* output file handle */
	int i;                  /* loop index */
	int nr_pt, pt_off;
	char cmd[80];
	char c;
	char *ptr;
	float yoff, ymult, xincr, xzero;
	char   time[12], date[12], xunit[12], yunit[12];

	memset( cmd, 0, 80 ); /* initialize command string to all nulls */

/*
 * Assign unique identifiers to the device DEV1 store it in the
 * variable "scope" and check for errors. If DEV1 is not defined,
 * ibfind returns -1.
 */
	if( ((scope = ibfind("DEV1")) < 0) ||
	    ((brd = ibfind("GPIB0")) < 0))
	{
		gpiberr("ibfind Error: Unable to find device/board!");
		exit(0);
	}

/*
 *  Clear the device and check for errors.
 */
	if ((ibclr(scope) < 0) ||
	   (ibsre(brd,0) < 0))
	{
		gpiberr("ibclr/ibsre Error: Unable to clear device/board!");
		exit(0);
	}

/*
 * Open the output file.
 */
	if (( outfile = fopen( "WFM_DATA.PRN", "wb" )) == NULL)
	{
		fprintf(stderr, "can't open output file %s\n");
		exit(1);
	}

/*
 *  Print a message on the screen instructing the user to connect Channel 1
 *  to the test signal.
 */
	printf("\n\n\t     TDS 300 Series GETWFM Program - Version 1.0\n\n\n");
	printf("\t***  Connect your test signal to Channel 1  ***\n\n");
	printf("\t     For example, you might connect the PROBE COMP signal\n");
	printf("\t     to the Channel 1 input connector using a 10X probe.\n");
	printf("\t     \n\n");
	printf("\t***  Press any key when done \n");
	getch();

/*
 * Prepare to read waveform data.
 */
	sprintf( cmd, "DATA:SOURCE CH1");
	if((gpibWrite( scope, cmd ) < 0) ||
	   (gpibWrite( scope, "DATA:ENCDG RIBINARY;WIDTH 1") < 0)||
	   (gpibWrite( scope, "HORIZONTAL:RECORDLENGTH 500") < 0) ||
	   (gpibWrite( scope, "DATA:START 1") < 0)||
	   (gpibWrite( scope, "DATA:STOP 500") < 0)||
	   (gpibWrite( scope, "HEADER OFF") < 0))
	{
	   gpiberr("ibwrt Error: Unable to Setup waveform parameters");
	   exit(1);
	}
/*
 * Make sure setup changes have taken effect and a new waveform is acquired
 */
	if (gpibWrite( scope, "ACQUIRE:STATE RUN") < 0)
	{
		gpiberr("Error: GPIB error or timeout waiting to acquire waveform");
		exit(1);
	}

/*
 * Read screen image data.
 *
 */
	if (gpibWrite( scope, "CURVE?") < 0)
	{
		gpiberr("ibwrt Error: CURVE?");
		exit(1);
	}
/*
 * Read in the header information. The header includes #<x><yyy>.
 */
	ibrd( scope, &c, 1 );      /* read in the '#' symbol */
	ibrd( scope, &c, 1 );      /* read in string length of num bytes to transfer */
	rslt = atoi(&c);           /* convert string to integer */
	ibrd( scope, cmd, rslt );  /* read in string containing num bytes to transfer */
	cmd[rslt]='\0';            /* force a null terminated string */
	rslt = atoi(cmd);          /* num bytes to transfer */

/*
 * Read the raw waveform data including the linefeed at the end.
 */
	if((ibrd( scope, wfm, rslt ) < 0) ||
	   (ibrd( scope, &c, 1 ) < 0))
	{
		gpiberr("ibrd Error: WAVEFORM");
		exit(1);
	}
/*
 * Read the waveform preamble.
 */
	sprintf( cmd, "WFMPRE:CH1:NR_PT?;YOFF?;YMULT?;XINCR?;PT_OFF?;XUNIT?;YUNIT?");
	if(gpibWrite( scope, cmd ) < 0)
	{
		gpiberr("ibwrt Error: WFMPRE?");
		exit(1);
	}
	memset( cmd, 0, 80 );   /* initialize the string buffer */
	if(ibrd( scope, cmd, 80 ) < 0)
	{
		gpiberr("ibrd Error: WFMPRE");
		exit(1);
	}
	sscanf( cmd, "%d;%e;%e;%e;%d;%[^;];%s", &nr_pt, &yoff, &ymult,
				&xincr, &pt_off, xunit, yunit );

	_strdate( date );
	_strtime( time );

/*
 * Process waveform data
 */

/*
 * Output header (x-, y-units, date, time and source)
 */
	fprintf(outfile, "%s,%s,\"%s\",\"%s\",\"%s\"\n",
		xunit, yunit, date, time, "CH1");

/*
 * Output scaled x, y values in (Sec, Volts)
 * Time[i] = (i - PTOFF) * XINCR
 * Volts[i] = (point value - YOFF) * YMULT
 */
	for(i=0;i<nr_pt;i++)
	{
		fprintf(outfile, "%14.12f,%14.12f\n\r",
			(float)(i-pt_off)*(float)(xincr),
			(float)(((float)wfm[i] - (float)yoff) * ymult));
	}

/*
 * Cleanup time
 */
	fclose(outfile);
	printf("\n\n\t     Waveform from channel CH1 successfully ");
	printf("transferred.\n");
	printf("\n\t     Number of waveform points is %d.\n",nr_pt);
	printf("\n\t     Waveform time and voltage points are in");
	printf(" file WFM_DATA.PRN\n\n");
	exit(0);
}
